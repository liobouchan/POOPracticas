/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cuenta;

import cuenta.vistas.ViewCliente;


/**
 *
 * @author lio
 */
public class Main {
    public static void main(String args[]){
        ViewCliente vistaCliente = new ViewCliente();
        vistaCliente.setVisible(true);
    }
}
